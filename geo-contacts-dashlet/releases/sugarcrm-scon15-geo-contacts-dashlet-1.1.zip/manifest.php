<?php
$manifest = array (
  'id' => 'scon15-geo-contacts-dashlet-1.1',
  'name' => 'SugarCon 2015 Elastichsearch Geo Searching POC',
  'readme' => 'NOTE: Please run a full search re-index (delete existing data).',
  'description' => 'Adds a Contacts Near Me dashlet used to locate nearby contacts',
  'version' => '1.1',
  'author' => 'SugarCRM, Inc.',
  'is_uninstallable' => 'true',
  'published_date' => '2015-04-20 22:13:35',
  'type' => 'module',
  'acceptable_sugar_versions' => 
  array (
    'exact_matches' => 
    array (
    ),
    'regex_matches' => 
    array (
      0 => '7\\.[56]*',
    ),
  ),
);
$installdefs = array (
  'id' => 'scon15-geo-contacts-dashlet-1.1',
  'custom_fields' => 
  array (
    'Contactslat_long_c' => 
    array (
      'id' => 'Contactslat_long_c',
      'name' => 'lat_long_c',
      'label' => 'LBL_LAT_LONG_C',
      'comments' => '',
      'help' => '',
      'module' => 'Contacts',
      'type' => 'varchar',
      'max_size' => '255',
      'require_option' => '0',
      'default_value' => '',
      'date_modified' => '2015-04-17 22:49:15',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '1',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => '',
      'ext2' => '',
      'ext3' => '',
      'ext4' => '',
    ),
    'Accountslat_long_c' => 
    array (
      'id' => 'Accountslat_long_c',
      'name' => 'lat_long_c',
      'label' => 'LBL_LAT_LONG_C',
      'comments' => '',
      'help' => '',
      'module' => 'Accounts',
      'type' => 'varchar',
      'max_size' => '255',
      'require_option' => '0',
      'default_value' => '',
      'date_modified' => '2015-04-17 22:49:15',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '1',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => '',
      'ext2' => '',
      'ext3' => '',
      'ext4' => '',
    ),
  ),
  'copy' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/src/custom/.DS_Store',
      'to' => 'custom/.DS_Store',
    ),
    1 => 
    array (
      'from' => '<basepath>/src/custom/clients/base/api/GeoApi.php',
      'to' => 'custom/clients/base/api/GeoApi.php',
    ),
    2 => 
    array (
      'from' => '<basepath>/src/custom/clients/base/views/geo-dashlet/geo-dashlet.hbs',
      'to' => 'custom/clients/base/views/geo-dashlet/geo-dashlet.hbs',
    ),
    3 => 
    array (
      'from' => '<basepath>/src/custom/clients/base/views/geo-dashlet/geo-dashlet.js',
      'to' => 'custom/clients/base/views/geo-dashlet/geo-dashlet.js',
    ),
    4 => 
    array (
      'from' => '<basepath>/src/custom/clients/base/views/geo-dashlet/geo-dashlet.php',
      'to' => 'custom/clients/base/views/geo-dashlet/geo-dashlet.php',
    ),
    5 => 
    array (
      'from' => '<basepath>/src/custom/clients/base/views/geo-dashlet/popup.hbs',
      'to' => 'custom/clients/base/views/geo-dashlet/popup.hbs',
    ),
    6 => 
    array (
      'from' => '<basepath>/src/custom/Extension/application/Ext/LogicHooks/GeoSearch.php',
      'to' => 'custom/Extension/application/Ext/LogicHooks/GeoSearch.php',
    ),
    7 => 
    array (
      'from' => '<basepath>/src/custom/Extension/modules/Accounts/Ext/Language/en_us.lang.php',
      'to' => 'custom/Extension/modules/Accounts/Ext/Language/en_us.lang.php',
    ),
    8 => 
    array (
      'from' => '<basepath>/src/custom/Extension/modules/Accounts/Ext/Vardefs/sugarfield_lat_long_c.php',
      'to' => 'custom/Extension/modules/Accounts/Ext/Vardefs/sugarfield_lat_long_c.php',
    ),
    9 => 
    array (
      'from' => '<basepath>/src/custom/Extension/modules/Contacts/Ext/Language/en_us.lang.php',
      'to' => 'custom/Extension/modules/Contacts/Ext/Language/en_us.lang.php',
    ),
    10 => 
    array (
      'from' => '<basepath>/src/custom/Extension/modules/Contacts/Ext/Vardefs/sugarfield_lat_long_c.php',
      'to' => 'custom/Extension/modules/Contacts/Ext/Vardefs/sugarfield_lat_long_c.php',
    ),
    11 => 
    array (
      'from' => '<basepath>/src/custom/include/SugarSearchEngine/Elastic/SugarSearchEngineElasticMapping.php',
      'to' => 'custom/include/SugarSearchEngine/Elastic/SugarSearchEngineElasticMapping.php',
    ),
    12 => 
    array (
      'from' => '<basepath>/src/custom/LogicHooks/GoogleGeoApiClient.php',
      'to' => 'custom/LogicHooks/GoogleGeoApiClient.php',
    ),
  ),
);
